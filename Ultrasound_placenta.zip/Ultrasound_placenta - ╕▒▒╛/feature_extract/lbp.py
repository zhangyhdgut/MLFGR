import numpy as np

def Lbp(gray):
# 计算LBP图像
    lbp = np.zeros_like(gray)
    for i in range(1, gray.shape[0] - 1):
        for j in range(1, gray.shape[1] - 1):
            center = gray[i, j]
            code = 0
            code |= (gray[i - 1, j - 1] > center) << 7
            code |= (gray[i - 1, j] > center) << 6
            code |= (gray[i - 1, j + 1] > center) << 5
            code |= (gray[i, j + 1] > center) << 4
            code |= (gray[i + 1, j + 1] > center) << 3
            code |= (gray[i + 1, j] > center) << 2
            code |= (gray[i + 1, j - 1] > center) << 1
            code |= (gray[i, j - 1] > center) << 0
            lbp[i, j] = code
    return lbp