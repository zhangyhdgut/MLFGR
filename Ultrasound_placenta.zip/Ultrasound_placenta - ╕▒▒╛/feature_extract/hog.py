import cv2
import numpy as np


def Hog(img):
    winSize = (160, 160)
    blockSize = (16, 16)
    blockStride = (8, 8)
    cellSize = (8, 8)
    nbins = 9

    # 创建HOG描述符对象
    hog = cv2.HOGDescriptor(winSize, blockSize, blockStride, cellSize, nbins)

    # 对输入图像计算HOG描述符
    hist = hog.compute(img)

    return hist

def hog_extract(image):
    img_hogs = []
    for img in image:
        img_hog = Hog(img)
        img_hog = img_hog.reshape(-1, 36)
        img_hogs.append(img_hog)
    img_hogs = np.array(img_hogs)
    return img_hogs

