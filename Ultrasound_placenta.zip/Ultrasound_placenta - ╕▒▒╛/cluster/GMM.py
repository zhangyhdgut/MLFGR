from sklearn.mixture import GaussianMixture


def Gmm(data, k):
    gmm = GaussianMixture(n_components = k)
    gmm.fit(data)
    return gmm


