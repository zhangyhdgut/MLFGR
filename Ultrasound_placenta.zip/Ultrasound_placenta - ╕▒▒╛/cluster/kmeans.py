import cv2


class Kmeans():
    def __init__(self):
        self.criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)

    def __call__(self, img_hogs, k):
        ret, labels, centers = cv2.kmeans(img_hogs, k, None, self.criteria, 10, cv2.KMEANS_PP_CENTERS)
        return centers

