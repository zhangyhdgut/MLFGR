import numpy as np


#Knn思想
def Knn(image_feature, centers):
    img_features_knn = []
    for img_feature in image_feature:
        centers_num = len(centers)
        feature_num = img_feature.shape[0]
        dist = np.zeros((feature_num, centers_num))
        for i, x in enumerate(img_feature):
            for j, c in enumerate(centers):
                dist[i][j] = np.linalg.norm(x - c, 2)
        min_indices = np.argmin(dist, axis=1)
        img_feature_knn = np.zeros(centers_num)
        for i in range(feature_num):
            n = min_indices[i]
            img_feature_knn[n] = img_feature_knn[n] + 1
        img_features_knn.append(img_feature_knn)
    img_features_knn = np.array(img_features_knn)
    return img_features_knn

#softmax距离缩放
def knn_s(image_feature, centers):
    img_features_knn = []
    for img_feature in image_feature:
        centers_num = len(centers)
        feature_num = img_feature.shape[0]
        dist = np.zeros((feature_num, centers_num))
        for i, x in enumerate(img_feature):
            for j, c in enumerate(centers):
                dist[i][j] = np.linalg.norm(x - c, 2)
        for i in range(feature_num):
            for j in range(centers_num):
                dist[i][j] = np.exp(-dist[i][j])
        dist_sum = np.sum(dist, axis=1)
        for i in range(feature_num):
            for j in range(centers_num):
                dist[i][j] = dist[i][j] / dist_sum[i]
        img_feature_softmax = np.sum(dist, axis=0)
        img_features_knn.append(img_feature_softmax)
    img_features_knn = np.array(img_features_knn)
    return img_features_knn

#FCM距离缩放
def fcm(image_feature, centers, m):
    img_features_fcm = []
    for img_feature in image_feature:
        centers_num = len(centers)
        feature_num = img_feature.shape[0]
        U = np.random.random((feature_num, centers_num))
        U = np.divide(U, np.sum(U, axis=1)[:, np.newaxis])
        U = U ** m
        dist = np.zeros((feature_num, centers_num))
        for i, x in enumerate(img_feature):
            for j, c in enumerate(centers):
                dist[i][j] = np.linalg.norm(x - c, 2)
        for i, x in enumerate(img_feature):
            for j, c in enumerate(centers):
                U[i][j] = 1. / np.sum((dist[i][j] / dist[i]) ** (2 / (m - 1)))
        img_feature_fcm = np.sum(U, axis=0)
        img_features_fcm.append(img_feature_fcm)
    img_features_fcm = np.array(img_features_fcm)
    return img_features_fcm

#GMM权重缩放
def gmm_s(image_feature, gmm, k, m):
    image_feature_gmm = []
    for img_feature in image_feature:
        num_anchor = img_feature.shape[0]
        predict = gmm.predict(img_feature)
        predict_w = np.zeros((num_anchor, k))
        for i in range(predict_w.shape[0]):
            predict_w[i][predict[i]] = 1
        predict_prop = gmm.predict_proba(img_feature)
        for i in range(num_anchor):
            predict_prop[i] = predict_w[i]*m + predict_prop[i]*(1-m)
        img_feature_gmm = np.sum(predict_prop, axis = 0)
        image_feature_gmm.append(img_feature_gmm)
    image_feature_gmm = np.array(image_feature_gmm)
    return image_feature_gmm
