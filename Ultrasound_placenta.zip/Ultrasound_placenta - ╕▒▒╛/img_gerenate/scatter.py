import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


# 假设x和y是你的数据
size = 15
x = [32, 64, 128, 256, 512, 1024]
y = [64.16, 67.83, 70.86, 72.77, 71.89, 71.11]

# 使用matplotlib.pyplot.scatter绘制散点图
plt.scatter(x, y, marker='^', color='orange', s=100)

# 标签
for i, txt in enumerate(y):
    if i == 0:
        plt.text(x[i]+3, y[i]+2, '{:.2f}%'.format(txt), ha='center', fontsize=size)
    else :
        plt.text(x[i], y[i]+2, '{:.2f}%'.format(txt), ha='center', fontsize=size)
    
# 划线
plt.plot(x, y, color='orange')

# 设置x轴
plt.xticks(x, fontsize=size)
plt.xscale('log', base=2)
formatter = ticker.FuncFormatter(lambda x, pos: '{:0.0f}'.format(x))
plt.gca().xaxis.set_major_formatter(formatter)

# 设置y轴
plt.ylim(0, 100)
plt.yticks(range(0, 101, 10), fontsize=size)
formatter = ticker.FuncFormatter(lambda y, pos: '{:0.0f}%'.format(y))
plt.gca().yaxis.set_major_formatter(formatter)

# 设置标签
plt.xlabel('K', fontsize=size+3)
plt.ylabel('Accuracy(%)', fontsize=size+3)

# 显示图像
plt.show()