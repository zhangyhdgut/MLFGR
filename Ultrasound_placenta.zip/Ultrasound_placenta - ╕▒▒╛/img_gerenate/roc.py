from pathlib import Path
import sys


#更新搜索路径，获取当前绝对路径
FILE = Path(__file__).resolve()  #获取当前脚本的绝对路径
ROOT = FILE.parents[1]         #获取当前文件的2级父目录
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))    #添加到搜索路径


from scipy.signal import savgol_filter
from feature_extract.hog import *
from cluster.kmeans import *
from cluster.GMM import Gmm
from bovw.Bovw import *
from sklearn.metrics import accuracy_score, auc
from classifer.utils import *
import time
from sklearn.svm import SVC
from sklearn.metrics import roc_curve
import matplotlib.pyplot as plt


#导入数据并切分数据集
image = np.load(r'D:\code_p\Ultrasound_placenta\img_preprocess\np\image_np.npy')
label = np.load(r'D:\code_p\Ultrasound_placenta\img_preprocess\np\label_np.npy')
k = 100
m = 0.15
n = 0.7
size = 15

for i in range(10):
    # 随机切分数据集并训练
    index1 = np.random.choice(53, size=53, replace=False)
    index2 = np.random.choice(99, size=99, replace=False) + 53
    train_index = np.concatenate((index1[:37], index2[:70]))
    test_index = np.concatenate((index1[37:], index2[70:]))
    train_data = image[train_index]
    train_label = label[train_index]
    test_data = image[test_index]
    test_label = label[test_index]
    print('测试图片数目为：{}'.format(test_data.shape[0]))
    print('检测中............')

    # 特征提取
    time1 = time.time()
    train_feature = hog_extract(train_data)
    test_feature = hog_extract(test_data)
    print(train_feature.shape, test_feature.shape)

    # 构建视觉字典
    # kmeans = Kmeans()
    # centers_k = kmeans(train_feature.reshape(-1, 36).astype(np.float32), k)
    gmm = Gmm(train_feature.reshape(-1, 36), k)
    centers_g = gmm.means_

    # 统计
    # train_feature_g = knn_s(train_feature, centers_k)
    # test_feature_g = knn_s(test_feature, centers_k)
    # print(train_feature_g.shape, test_feature_g.shape)
    train_feature_g = gmm_s(train_feature, gmm, k, m)
    test_feature_g = gmm_s(test_feature, gmm, k, m)
    print(train_feature_g.shape, test_feature_g.shape)

    # 计算指标
    test_label = test_label.astype(np.int32)
    model_svm_g = SVC(kernel='rbf')
    model_svm_g.fit(train_feature_g, train_label)
    model_predict = model_svm_g.predict(test_feature_g).astype(np.int32)
    print('gmm_svm_acc:{}'.format(accuracy_score(model_predict, test_label)))

    #roc曲线的绘制
    fpr, tpr, thresholds = roc_curve(test_label, model_svm_g.decision_function(test_feature_g))
    roc_auc = auc(fpr, tpr)
    plt.figure()
    plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.0])
    plt.xlabel('False Positive Rate', fontsize=size)
    plt.ylabel('True Positive Rate', fontsize=size)
    plt.title('Receiver operating characteristic example', fontsize=size)
    plt.legend(loc="lower right", fontsize=size)
    plt.savefig(r'D:\code_p\Ultrasound_placenta\img_gerenate\{}.jpg'.format(i+1), dpi=800)
    print("成功绘制第{}张图像".format(i+1))
