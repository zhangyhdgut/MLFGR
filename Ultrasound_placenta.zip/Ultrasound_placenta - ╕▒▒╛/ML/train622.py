from feature_extract.hog import *
from feature_extract.lbp import *
from cluster.kmeans import *
from cluster.GMM import Gmm
from bovw.Bovw import *
from sklearn.svm import SVC, LinearSVC
from sklearn.metrics import accuracy_score, recall_score, precision_score
import torch
from classifer.BLS import broadNet
from classifer.utils import *

#导入数据并切分数据集
image = np.load(r'D:\code\Ultrasound_placenta\img_preprocess\np\image_np.npy')
label = np.load(r'D:\code\Ultrasound_placenta\img_preprocess\np\image_label.npy')
k = 100
m = 0.15
n = 0.75

for i in range(10):
    # 随机切分数据集并训练
    index1 = np.random.choice(55, size=55, replace=False)
    index2 = np.random.choice(46, size=46, replace=False) + 55
    train_index = np.concatenate((index1[:33], index2[:28]))
    evl_index = np.concatenate((index1[33:44], index2[28:37]))
    test_index = np.concatenate((index1[44:], index2[37:46]))
    train_data = image[train_index]
    train_label = label[train_index]
    evl_data = image[evl_index]
    evl_label = label[evl_index]
    test_data = image[test_index]
    test_label = label[test_index]
    print(train_data.shape, train_label.shape, evl_data.shape, evl_label.shape, test_data.shape, test_label.shape)

    # 特征提取
    train_feature = hog_extract(train_data)
    evl_feature = hog_extract(evl_data)
    test_feature = hog_extract(test_data)
    print(train_feature.shape, evl_feature.shape, test_feature.shape)

    # 构建视觉字典
    # kmeans = Kmeans()
    # centers_k = kmeans(train_feature.reshape(-1, 36).astype(np.float32), k)
    # print(centers_k.shape)
    gmm = Gmm(train_feature.reshape(-1, 36), k)
    centers_g = gmm.means_
    print(centers_g.shape)

    # 特征编码
    # train_feature_k = knn_s(train_feature, centers_k)
    # test_feature_k = knn_s(test_feature, centers_k)
    # print(train_feature_k.shape, test_feature_k.shape)
    train_feature_g = gmm_s(train_feature, gmm, k, m)
    evl_feature_g = gmm_s(evl_feature, gmm, k, m)
    test_feature_g = gmm_s(test_feature, gmm, k, m)
    print(train_feature_g.shape, test_feature_g.shape)

    # 训练
    evl_label = evl_label.astype(np.int32)
    test_label = test_label.astype(np.int32)
    #evl测试
    model_svm_g = SVC(kernel='rbf')
    model_svm_g.fit(train_feature_g, train_label)
    model_bls_g = broadNet(map_num=5, enhance_num=5, map_function='relu', enhance_function='relu', batchsize=20)
    model_bls_g.fit(train_feature_g, train_label.reshape(1, -1))
    model1_predict = model_svm_g.predict(evl_feature_g).astype(np.int32)
    model2_predict = model_bls_g.predict(evl_feature_g).astype(np.int32)
    final_predict = np.append(model1_predict[:11], model2_predict[11:])
    print('gmm_svm_bls_evl:{}'.format(accuracy_score(final_predict, evl_label)))
    model1_predict_test = model_svm_g.predict(test_feature_g).astype(np.int32)
    model2_predict_test = model_bls_g.predict(test_feature_g).astype(np.int32)
    final_predict_test = np.append(model1_predict_test[:11], model2_predict_test[11:])
    print('gmm_svm_bls_test:{}'.format(accuracy_score(final_predict_test, test_label)))

    model1_predict2 = sigmod(np.array(model_svm_g.decision_function(evl_feature_g)))
    model2_predict2 = softmax(np.array(model_bls_g.predict_proba(evl_feature_g)))
    final_predict2 = np.argmax(model1_predict2*n + model2_predict2*(1.0-n), axis = 1)
    print('gmm_svm+bls_evl:{}'.format(accuracy_score(final_predict2, evl_label)))
    print(final_predict2, evl_label)
    model1_predict2_test = sigmod(np.array(model_svm_g.decision_function(test_feature_g)))
    model2_predict2_test = softmax(np.array(model_bls_g.predict_proba(test_feature_g)))
    final_predict2_test = np.argmax(model1_predict2_test*n + model2_predict2_test*(1.0-n), axis = 1)
    print('gmm_svm+bls_test:{}'.format(accuracy_score(final_predict2_test, test_label)))
    print(final_predict2_test, test_label)
