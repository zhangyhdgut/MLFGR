import pywt
import numpy as np
import cv2


#小波变换
def wavelet_denoising(src, wavelet='db1', level=1):
    # 将图像转换为灰度图像
    img = src.copy()

    if len(src.shape) > 2:#维度>2
        img = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)

    # 将图像转换为numpy数组
    img_array = np.array(img)

    # 进行小波分解
    coeffs = pywt.wavedec2(img_array, wavelet, level=level)

    # 对每个子带进行去噪处理
    for i in range(1, len(coeffs)):
        coeffs[i] = tuple([pywt.threshold(j, value=20, mode='soft') for j in coeffs[i]])

    # 重构图像
    img_denoised = pywt.waverec2(coeffs, wavelet)

    # 将图像转换为uint8格式
    img_denoised = np.uint8(img_denoised)

    return img_denoised