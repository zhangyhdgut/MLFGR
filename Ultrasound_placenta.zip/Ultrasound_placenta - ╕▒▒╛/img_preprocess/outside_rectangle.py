import cv2


def maximum_outside_rectangle(img_path):
    # 读取图像
    img = cv2.imread(img_path)

    # 转换为灰度图像
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 应用阈值以获取二值图像
    _, thresh = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)

    # 查找轮廓
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # 初始化最大面积和最大矩形的坐标
    max_area = 0
    max_rect = (0, 0, 0, 0)

    for cnt in contours:
        # 对于每个轮廓，找到最小的外接矩形
        x, y, w, h = cv2.boundingRect(cnt)
        # 计算面积
        area = w * h
        # 如果这个矩形的面积大于当前最大面积，则更新最大面积和最大矩形的坐标
        if area > max_area:
            max_area = area
            max_rect = (x, y, w, h)

    # 裁剪出最大的外接矩形
    x, y, w, h = max_rect
    cropped = img[y:y+h, x:x+w]

    # 返回裁剪后的图像
    return cropped