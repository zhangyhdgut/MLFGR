import csv
import cv2
import numpy as np
from inside_rectangle import maximum_internal_rectangle
from wavelet import wavelet_denoising
import time
from outside_rectangle import maximum_outside_rectangle
import os


#读取csv文件
image, label = [], []
with open(r'D:\code_p\Ultrasound_placenta\data\label.csv') as f:
    reader = csv.reader(f)
    for row in reader:
        i, l = row
        image.append(i)
        label.append(l)

def show(img):
    cv2.imshow('aaa', img)
    cv2.waitKey()
    cv2.destroyAllWindows()

#预处理
image_label = label
image_np = []
size = 160
n = 0
for img_dir in image:
    #读取图片转为灰度图
    img = cv2.imread(img_dir)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 外接矩形裁剪
    # img_gray = maximum_outside_rectangle(img_dir)
    # img_gray = cv2.resize(img_gray, (size, size), cv2.INTER_AREA)  # 功能区图片的大小变换

    # 内接矩形裁剪
    img_gray = maximum_internal_rectangle(img, img_gray)  # 功能区的裁剪
    img_gray = cv2.resize(img_gray, (size, size), cv2.INTER_AREA)  # 功能区图片的大小变换

    # 去噪处理
    img_denoising = wavelet_denoising(img_gray)  # 小波变换处理
    image_np.append(img_denoising)
    
    # 存储图片
    if (img_dir.split('\\')[-2] == 'FGR'):
        cv2.imwrite(os.path.join(r'D:\code_p\Ultrasound_placenta\data\img-ROI\FGR_ROI', img_dir.split('\\')[-1]), img_denoising)
    else :
        cv2.imwrite(os.path.join(r'D:\code_p\Ultrasound_placenta\data\img-ROI\Normal_ROI', img_dir.split('\\')[-1]), img_denoising)


# image_label = np.array(image_label)
# image_np = np.array(image_np)
# print(image_np.shape)
# print(image_label)
# np.save(r'D:\code\Ultrasound_placenta\img_preprocess\np\image_np.npy', image_np)
# np.save(r'D:\code\Ultrasound_placenta\img_preprocess\np\label_np.npy', image_label)

