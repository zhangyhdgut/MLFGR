import os, glob
import csv
import random


'1.读取数据类别并对应数字'
class_to_num = {}
class_name_list = os.listdir(r'D:\code_p\Ultrasound_placenta\data\img-ROI')
#os.listdir('root') 将该目录下文件的名字以字符串形式存在列表中并返回
for class_name in class_name_list:
    class_to_num[class_name] = len(class_to_num.keys())
print(class_name_list)

'2.存储所有图片的路径名字'
image_dir = []
for class_name in class_name_list:
    image_dir += glob.glob(os.path.join(r'D:\code_p\Ultrasound_placenta\data\img-ROI', class_name, '*.png'))
    #os.path.join('root1', 'root2') 将多个路径名进行拼接并返回字符串路径列表
    #golb.golb('root.*.sname) 搜索该路径下满足*和.jpg后缀名的文件并以列表形式返回所有满足条件的文件的路径文件名
random.shuffle(image_dir)   #random.shuffle(struct) 将结构里面的内容打乱
print(len(image_dir))

'3.制作csv文件'
with open(r'D:\code_p\Ultrasound_placenta\data\label-ROI.csv', mode ='w', newline ='') as f:
    # with open('name.sname'， mode, newline) as f: python中打开文件操作
    write = csv.writer(f)
    #csv.write(document) 创建csv写对象，传入需要写的文件进行绑定
    for image in image_dir:
        class_name = image.split(os.sep)[-2]
        #os.sep 系统文件路径分隔符返回字符串
        #image.split('#') 以#分割字符串，并返回字符串列表
        label = class_to_num[class_name]
        write.writerow([image, label])
        #write.writerow([1,2,3,……]) 将列表内容以字符串形式写入csv文件中，以','为单元格分割符
print('write ok!')
