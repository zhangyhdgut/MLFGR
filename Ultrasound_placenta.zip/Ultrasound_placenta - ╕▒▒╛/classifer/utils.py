import numpy as np


def softmax(predict):
    for i in range(predict.shape[0]):
        sum = 0
        for j in range(predict.shape[1]):
            sum = sum + np.exp(predict[i][j])
        for j in range(predict.shape[1]):
            predict[i][j] = np.exp(predict[i][j]) / sum
    return predict


def sigmod(score):
    props = []
    for i in range(score.shape[0]):
        prop = np.array([0., 0.])
        prop[1] = 1.0 / (1.0 + np.exp(-score[i]))
        prop[0] = 1.0 - prop[1]
        props.append(prop)
    return np.array(props)